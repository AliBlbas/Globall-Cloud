drop extension if exists pg_graphql;;
