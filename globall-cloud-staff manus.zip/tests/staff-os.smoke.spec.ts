import { expect, test, type Page } from "@playwright/test";

const staffPath = process.env.STAFF_PATH ?? "/";

async function collectConsoleErrors(page: Page) {
  const errors: string[] = [];
  page.on("console", message => {
    if (message.type() === "error") errors.push(message.text());
  });
  page.on("pageerror", error => errors.push(error.message));
  return errors;
}

test.describe("Staff OS browser smoke", () => {
  test("loads the Staff Console shell without browser errors", async ({ page }) => {
    const errors = await collectConsoleErrors(page);
    await page.goto(staffPath, { waitUntil: "networkidle" });
    await expect(page.locator("body")).toBeVisible();
    await expect(page.locator("body")).toContainText(/Staff|ستاف|Globall Cloud/i);
    expect(errors).toEqual([]);
  });

  test("does not introduce horizontal overflow on the target viewport", async ({ page }) => {
    await page.goto(staffPath, { waitUntil: "domcontentloaded" });
    const dimensions = await page.evaluate(() => ({
      viewport: document.documentElement.clientWidth,
      content: document.documentElement.scrollWidth,
    }));
    expect(dimensions.content).toBeLessThanOrEqual(dimensions.viewport + 1);
  });

  test("keeps Staff links on the configured same-origin path when present", async ({ page }) => {
    await page.goto(staffPath, { waitUntil: "domcontentloaded" });
    const links = await page.locator('a[href*="staff"]').evaluateAll(anchors => anchors.map(anchor => (anchor as HTMLAnchorElement).href));
    for (const link of links) {
      expect(new URL(link).origin).toBe(new URL(page.url()).origin);
    }
  });

  test("supports keyboard focus on interactive controls", async ({ page }) => {
    await page.goto(staffPath, { waitUntil: "domcontentloaded" });
    const firstInteractive = page.locator("button, a, input").first();
    await expect(firstInteractive).toBeVisible();
    await firstInteractive.focus();
    await expect(firstInteractive).toBeFocused();
  });
});
