# Staff OS automated testing

The Staff OS test platform has two layers. Vitest covers server-side contracts and authorization without touching production data. Playwright covers browser smoke behavior across desktop Chrome and an iPhone-sized viewport.

## Server tests

Run the deterministic server suite with:

```bash
pnpm test:server
```

These tests should use mocked database/storage boundaries for authorization and validation checks. Do not point destructive or fixture-writing tests at the production database. Any future integration fixture must use a dedicated test database or an explicit transaction that is rolled back after each test.

## Browser smoke tests

Run browser tests against the local project with:

```bash
pnpm test:browser
```

Run them against the official deployed Staff route with:

```bash
SMOKE_BASE_URL=https://globall-cloud.pages.dev STAFF_PATH=/staff pnpm test:browser
```

The browser suite checks that the shell loads without console errors, the target viewport has no horizontal overflow, visible Staff links stay same-origin, and keyboard focus reaches interactive controls. Authentication-required workflows should be covered in a separate authenticated project using a dedicated test account and stored session state; never commit that session state or any credential to the repository.

## Full quality gate

Run both layers with:

```bash
pnpm test:all
```

Before a release, also run `pnpm check` and `pnpm build`. A failure in the official `/staff` smoke run should block deployment until the deployment, routing, or authentication issue is understood.
## Continuous integration

The repository includes `.github/workflows/staff-os-quality.yml`. Pull requests and pushes to the production branches run dependency installation, Chromium setup, typecheck, server tests, desktop/mobile browser smoke tests, and the production build. The workflow does not use production credentials or write production data.
