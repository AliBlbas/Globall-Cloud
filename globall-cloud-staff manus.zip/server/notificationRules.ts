export type ShipmentNotificationStatus = "quoted" | "received" | "in_transit" | "customs" | "out_for_delivery" | "delivered" | "exception";
export type TaskPriority = "normal" | "high" | "critical";

export function shipmentNotificationDecision(status: ShipmentNotificationStatus, trackingCode: string) {
  const isException = status === "exception";
  return {
    kind: isException ? "exception" : "shipment_status",
    title: isException ? "ئاگادارییەکی گرنگی بار" : "دۆخی بار گۆڕدرا",
    body: `${trackingCode}: ${status}`,
    ownerTitle: "Shipment status changed",
    ownerContent: `${trackingCode} is now ${status}.`,
  } as const;
}

export function shouldNotifyTask(priority: TaskPriority, assignedTo?: number) {
  return priority !== "normal" || assignedTo !== undefined;
}

export function taskNotificationDecision(title: string) {
  return {
    kind: "priority_task" as const,
    title: "ئەرکی نوێ بۆ ستاف",
    body: title,
    ownerTitle: "Staff task created",
    ownerContent: title,
  };
}
