import { and, desc, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { auditLogs, attachments, customers, financeRecords, notifications, shipmentMilestones, shipments, staffMembers, staffTasks, users, warehouseReceipts } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); }
  }
  return _db;
}

export async function upsertUser(user: typeof users.$inferInsert): Promise<void> {
  const db = await getDb();
  if (!db || !user.openId) return;
  const values = { openId: user.openId, name: user.name ?? null, email: user.email ?? null, loginMethod: user.loginMethod ?? null, lastSignedIn: user.lastSignedIn ?? new Date() };
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: { name: values.name, email: values.email, loginMethod: values.loginMethod, lastSignedIn: values.lastSignedIn } });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return rows[0];
}

export async function getStaffRole(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(staffMembers).where(eq(staffMembers.userId, userId)).limit(1);
  return rows[0] ?? null;
}

export async function writeAudit(actorUserId: number, action: string, entityType: string, entityId: string | number | null, details?: unknown) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values({ actorUserId, action, entityType, entityId: entityId == null ? null : String(entityId), details: details ? JSON.stringify(details) : null });
}

export async function createNotification(type: "shipment_status" | "priority_task" | "exception" | "system", title: string, content: string, actionUrl?: string, recipientUserId?: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values({ type, title, content, actionUrl: actionUrl ?? null, recipientUserId: recipientUserId ?? null });
}

export async function searchCustomers(query: string) {
  const db = await getDb();
  if (!db) return [];
  const q = `%${query}%`;
  return db.select().from(customers).where(or(like(customers.name, q), like(customers.code, q), like(customers.phone, q), like(customers.email, q))).orderBy(desc(customers.updatedAt)).limit(50);
}

export async function listShipments(query?: string) {
  const db = await getDb();
  if (!db) return [];
  const rows = query ? await db.select().from(shipments).where(or(like(shipments.trackingCode, `%${query}%`), like(shipments.route, `%${query}%`))).orderBy(desc(shipments.updatedAt)).limit(50) : await db.select().from(shipments).orderBy(desc(shipments.updatedAt)).limit(50);
  return rows;
}

export { and, eq, desc, like, or, auditLogs, attachments, customers, financeRecords, notifications, shipmentMilestones, shipments, staffMembers, staffTasks, warehouseReceipts };
