export type StaffRole = "super_admin" | "admin" | "operations" | "warehouse" | "finance" | "support";

export function canAccessStaffSurface(userRole: string | undefined, staffRole: string | undefined, active: boolean | undefined, allowed: readonly StaffRole[]) {
  if (userRole === "admin" && allowed.includes("super_admin")) return true;
  return Boolean(active && staffRole && allowed.includes(staffRole as StaffRole));
}
