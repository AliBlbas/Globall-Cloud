import { describe, expect, it } from "vitest";
import { shipmentNotificationDecision, shouldNotifyTask, taskNotificationDecision } from "./notificationRules";

describe("notification rules", () => {
  it("marks exception shipment changes as urgent notifications", () => {
    expect(shipmentNotificationDecision("exception", "GC-1001")).toMatchObject({
      kind: "exception",
      title: "ئاگادارییەکی گرنگی بار",
      body: "GC-1001: exception",
    });
  });

  it("uses the standard shipment status channel for non-exception changes", () => {
    expect(shipmentNotificationDecision("in_transit", "GC-1002")).toMatchObject({
      kind: "shipment_status",
      body: "GC-1002: in_transit",
    });
  });

  it("notifies when a task is assigned or urgent", () => {
    expect(shouldNotifyTask("normal", undefined)).toBe(false);
    expect(shouldNotifyTask("normal", 14)).toBe(true);
    expect(shouldNotifyTask("critical", undefined)).toBe(true);
    expect(taskNotificationDecision("Check customs documents")).toMatchObject({
      kind: "priority_task",
      body: "Check customs documents",
    });
  });
});
