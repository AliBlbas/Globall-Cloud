import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { canAccessStaffSurface } from "./accessPolicy";
import type { TrpcContext } from "./_core/context";

function context(user: TrpcContext["user"]): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

const anonymous = context(null);
const admin = context({
  id: 1,
  openId: "admin-user",
  email: "admin@example.com",
  name: "Admin User",
  loginMethod: "test",
  role: "admin",
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
});

describe("Staff OS security boundaries", () => {
  it("rejects anonymous dashboard access", async () => {
    const caller = appRouter.createCaller(anonymous);
    await expect(caller.dashboard.summary()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects anonymous attachment uploads before storage access", async () => {
    const caller = appRouter.createCaller(anonymous);
    await expect(caller.attachments.upload({ shipmentId: 1, fileName: "cargo.png", mimeType: "image/png", dataBase64: "a-valid-looking-base64-payload" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects invalid shipment, task, and attachment payloads", async () => {
    const caller = appRouter.createCaller(admin);
    await expect(caller.shipments.create({ trackingCode: "x", customerId: 1, origin: "A", destination: "B", transport: "air", parcels: 1 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.tasks.create({ title: "x", priority: "normal" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.attachments.upload({ fileName: "cargo.png", mimeType: "image/png", dataBase64: "a-valid-looking-base64-payload" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("allows only active staff roles and gives admins the super-admin path", () => {
    expect(canAccessStaffSurface("admin", undefined, undefined, ["super_admin"])).toBe(true);
    expect(canAccessStaffSurface("user", "operations", true, ["operations"])).toBe(true);
    expect(canAccessStaffSurface("user", "operations", false, ["operations"])).toBe(false);
    expect(canAccessStaffSurface("user", "finance", true, ["warehouse"])).toBe(false);
  });

  it("keeps audit history read-only at the exposed router surface", () => {
    const source = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    const auditStart = source.indexOf("audit: router({");
    const auditEnd = source.indexOf("\n  }),", auditStart);
    const auditBlock = source.slice(auditStart, auditEnd);
    expect(auditBlock).not.toMatch(/\b(update|delete)\s*:/);
  });
});
