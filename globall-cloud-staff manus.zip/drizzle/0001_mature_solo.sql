CREATE TABLE `attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipment_id` int,
	`warehouse_receipt_id` int,
	`file_name` varchar(255) NOT NULL,
	`mime_type` varchar(120) NOT NULL,
	`file_key` varchar(500) NOT NULL,
	`file_url` varchar(700) NOT NULL,
	`uploaded_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actor_user_id` int NOT NULL,
	`action` varchar(120) NOT NULL,
	`entity_type` varchar(80) NOT NULL,
	`entity_id` varchar(80),
	`details` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`name` varchar(160) NOT NULL,
	`phone` varchar(40),
	`email` varchar(320),
	`city` varchar(100),
	`notes` text,
	`active` int NOT NULL DEFAULT 1,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `finance_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipment_id` int NOT NULL,
	`type` enum('invoice','payment','refund') NOT NULL,
	`amount` varchar(32) NOT NULL,
	`currency` varchar(8) NOT NULL DEFAULT 'USD',
	`status` enum('pending','paid','void') NOT NULL DEFAULT 'pending',
	`receipt_key` varchar(500),
	`note` text,
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `finance_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recipient_user_id` int,
	`type` enum('shipment_status','priority_task','exception','system') NOT NULL,
	`title` varchar(220) NOT NULL,
	`content` text NOT NULL,
	`action_url` varchar(400),
	`read_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipment_milestones` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipment_id` int NOT NULL,
	`status` varchar(60) NOT NULL,
	`note` text,
	`created_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shipment_milestones_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tracking_code` varchar(40) NOT NULL,
	`customer_id` int NOT NULL,
	`origin` varchar(100) NOT NULL,
	`destination` varchar(100) NOT NULL,
	`route` varchar(200) NOT NULL,
	`transport` enum('air','sea','land') NOT NULL,
	`status` enum('quoted','received','in_transit','customs','out_for_delivery','delivered','exception') NOT NULL DEFAULT 'quoted',
	`priority` enum('normal','high','critical') NOT NULL DEFAULT 'normal',
	`parcels` int NOT NULL DEFAULT 1,
	`weight_kg` varchar(24),
	`total_amount` varchar(32),
	`payment_status` enum('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
	`exception_note` text,
	`assigned_to` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shipments_id` PRIMARY KEY(`id`),
	CONSTRAINT `shipments_tracking_code_unique` UNIQUE(`tracking_code`)
);
--> statement-breakpoint
CREATE TABLE `staff_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`display_name` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`role` enum('super_admin','admin','operations','warehouse','finance','support') NOT NULL,
	`branch` varchar(120) NOT NULL DEFAULT 'all branch',
	`active` int NOT NULL DEFAULT 1,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `staff_members_id` PRIMARY KEY(`id`),
	CONSTRAINT `staff_members_user_id_unique` UNIQUE(`user_id`)
);
--> statement-breakpoint
CREATE TABLE `staff_tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(220) NOT NULL,
	`description` text,
	`shipment_id` int,
	`assigned_to` int,
	`priority` enum('normal','high','critical') NOT NULL DEFAULT 'normal',
	`status` enum('unassigned','in_progress','done','overdue') NOT NULL DEFAULT 'unassigned',
	`due_at` timestamp,
	`created_by` int NOT NULL,
	`completed_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `staff_tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `warehouse_receipts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipment_id` int NOT NULL,
	`branch` varchar(120) NOT NULL,
	`parcel_count` int NOT NULL,
	`checked_count` int NOT NULL DEFAULT 0,
	`condition` enum('good','partial_damage','damaged','unknown') NOT NULL DEFAULT 'unknown',
	`note` text,
	`received_by` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `warehouse_receipts_id` PRIMARY KEY(`id`)
);
