import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const staffMembers = mysqlTable("staff_members", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().unique(),
  displayName: varchar("display_name", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  role: mysqlEnum("role", ["super_admin", "admin", "operations", "warehouse", "finance", "support"]).notNull(),
  branch: varchar("branch", { length: 120 }).default("all branch").notNull(),
  active: int("active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  email: varchar("email", { length: 320 }),
  city: varchar("city", { length: 100 }),
  notes: text("notes"),
  active: int("active").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const shipments = mysqlTable("shipments", {
  id: int("id").autoincrement().primaryKey(),
  trackingCode: varchar("tracking_code", { length: 40 }).notNull().unique(),
  customerId: int("customer_id").notNull(),
  origin: varchar("origin", { length: 100 }).notNull(),
  destination: varchar("destination", { length: 100 }).notNull(),
  route: varchar("route", { length: 200 }).notNull(),
  transport: mysqlEnum("transport", ["air", "sea", "land"]).notNull(),
  status: mysqlEnum("status", ["quoted", "received", "in_transit", "customs", "out_for_delivery", "delivered", "exception"]).default("quoted").notNull(),
  priority: mysqlEnum("priority", ["normal", "high", "critical"]).default("normal").notNull(),
  parcels: int("parcels").default(1).notNull(),
  weightKg: varchar("weight_kg", { length: 24 }),
  totalAmount: varchar("total_amount", { length: 32 }),
  paymentStatus: mysqlEnum("payment_status", ["unpaid", "partial", "paid"]).default("unpaid").notNull(),
  exceptionNote: text("exception_note"),
  assignedTo: int("assigned_to"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const shipmentMilestones = mysqlTable("shipment_milestones", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipment_id").notNull(),
  status: varchar("status", { length: 60 }).notNull(),
  note: text("note"),
  createdBy: int("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const warehouseReceipts = mysqlTable("warehouse_receipts", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipment_id").notNull(),
  branch: varchar("branch", { length: 120 }).notNull(),
  parcelCount: int("parcel_count").notNull(),
  checkedCount: int("checked_count").default(0).notNull(),
  condition: mysqlEnum("condition", ["good", "partial_damage", "damaged", "unknown"]).default("unknown").notNull(),
  note: text("note"),
  receivedBy: int("received_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const staffTasks = mysqlTable("staff_tasks", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 220 }).notNull(),
  description: text("description"),
  shipmentId: int("shipment_id"),
  assignedTo: int("assigned_to"),
  priority: mysqlEnum("priority", ["normal", "high", "critical"]).default("normal").notNull(),
  status: mysqlEnum("status", ["unassigned", "in_progress", "done", "overdue"]).default("unassigned").notNull(),
  dueAt: timestamp("due_at"),
  createdBy: int("created_by").notNull(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const financeRecords = mysqlTable("finance_records", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipment_id").notNull(),
  type: mysqlEnum("type", ["invoice", "payment", "refund"]).notNull(),
  amount: varchar("amount", { length: 32 }).notNull(),
  currency: varchar("currency", { length: 8 }).default("USD").notNull(),
  status: mysqlEnum("status", ["pending", "paid", "void"]).default("pending").notNull(),
  receiptKey: varchar("receipt_key", { length: 500 }),
  note: text("note"),
  createdBy: int("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const attachments = mysqlTable("attachments", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipment_id"),
  warehouseReceiptId: int("warehouse_receipt_id"),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  mimeType: varchar("mime_type", { length: 120 }).notNull(),
  fileKey: varchar("file_key", { length: 500 }).notNull(),
  fileUrl: varchar("file_url", { length: 700 }).notNull(),
  uploadedBy: int("uploaded_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  recipientUserId: int("recipient_user_id"),
  type: mysqlEnum("type", ["shipment_status", "priority_task", "exception", "system"]).notNull(),
  title: varchar("title", { length: 220 }).notNull(),
  content: text("content").notNull(),
  actionUrl: varchar("action_url", { length: 400 }),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actor_user_id").notNull(),
  action: varchar("action", { length: 120 }).notNull(),
  entityType: varchar("entity_type", { length: 80 }).notNull(),
  entityId: varchar("entity_id", { length: 80 }),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
